var my_module = require('./test_Mymodules');
console.log(my_module.Myfunc(2, 3));