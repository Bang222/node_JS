console.log("i am fist");
setTimeout(() => {
    console.log("I am second");
}, 500);
console.log("I am third");