/*My_func = function add_2(a,b){
    return a+b;
}
exports.My_func=My_func;*/
exports.Myfunc = (a, b) => a + b;